# eereid
Python module providing tools for training and evaluating re-identification models.
