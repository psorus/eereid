from .contrastive import contrastive
from .triplet import triplet
from .loss import loss
from .extended_triplet import extended_triplet
from .quadruplet import quadruplet
from .custom_loss import custom_loss
from .custom_loss import custom_loss as custom
