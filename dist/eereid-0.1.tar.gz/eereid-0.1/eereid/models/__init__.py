from .custom_model import custom_model
from .custom_model import custom_model as custom
from .model import model
from .simple_conv import simple_conv
from .simple_conv import simple_conv as conv
from .simple_dense import simple_dense
from .simple_dense import simple_dense as dense
