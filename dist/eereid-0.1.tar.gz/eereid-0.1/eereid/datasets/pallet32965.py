from eereid.datasets.downloadable import downloadable

class pallet32965(downloadable):
    def __init__(self):
        super().__init__('spallet32965')

    def explain(self):
        return "Pallet block 32965 data loader"


