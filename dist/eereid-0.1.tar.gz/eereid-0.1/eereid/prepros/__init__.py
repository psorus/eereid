from .add_color import add_color
from .blackwhite import blackwhite
from .flips import flips
from .prepro import prepro
from .reduce_dimension import reduce_dimension
from .resize import resize
from .rotations import rotations
from .subsample import subsample
